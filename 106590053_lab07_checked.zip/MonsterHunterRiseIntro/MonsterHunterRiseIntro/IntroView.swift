//
//  IntroView.swift
//  MonsterHunterRiseIntro
//
//  Created by user on 4/5/21.
//

import SwiftUI

struct IntroView: View {
    
    @Binding var showIntroPage:Bool
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .top), content: {
            Color.black
                .ignoresSafeArea()
            VStack{
                Spacer()
                Image("Intro")
                    .resizable()
                    .scaledToFit()
                    .padding(.bottom, 20)
                ForEach(0..<1){ item in
                    Text("《魔物獵人 崛起》是一款由卡普空开发并发行在任天堂Switch上的动作角色扮演游戏。本作是繼《魔物獵人XX》後再度登陆任天堂Switch上的魔物獵人系列作品，遊戲於2021年3月26日在全球同步發售。")
                        .foregroundColor(.white)
                }
                Spacer()
            }
            .overlay(
                Button(action: {
                    showIntroPage = false
                }, label: {
                    Image(systemName: "xmark.circle.fill")
                        .resizable()
                        .padding(20)
                        .frame(width: 75, height: 75)
                }), alignment: .topTrailing
            )
        })
        
    }
}

struct IntroView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView(showIntroPage: .constant(true))
    }
}
