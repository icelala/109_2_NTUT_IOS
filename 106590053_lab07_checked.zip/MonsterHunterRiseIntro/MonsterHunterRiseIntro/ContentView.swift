//
//  ContentView.swift
//  MonsterHunterRiseIntro
//
//  Created by user on 4/5/21.
//

import SwiftUI

struct ContentView: View {
    @State private var showIntroPage:Bool = false
    
    var body: some View {
        ZStack{
            Color.black.ignoresSafeArea()
            VStack(spacing:20){

                Text("Monster Hunter Rise")
                    .bold()
                    .font(.system(size: 35))
                    .foregroundColor(.white)
                    .padding(.top, 20)
                Spacer()
                Image("Cover")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    showIntroPage = true
                }, label: {
                    Text("Intro")
                        .font(.system(size:25))
                })
                Spacer()
            }
        }
        .sheet(isPresented: $showIntroPage, content: {
            IntroView(showIntroPage: $showIntroPage)
        })
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
