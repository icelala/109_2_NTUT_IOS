//
//  MonsterHunterRiseIntroApp.swift
//  MonsterHunterRiseIntro
//
//  Created by user on 4/5/21.
//

import SwiftUI

@main
struct MonsterHunterRiseIntroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
