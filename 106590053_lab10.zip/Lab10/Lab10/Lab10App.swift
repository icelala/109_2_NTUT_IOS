//
//  Lab10App.swift
//  Lab10
//
//  Created by user on 27/5/21.
//

import SwiftUI

@main
struct Lab10App: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
