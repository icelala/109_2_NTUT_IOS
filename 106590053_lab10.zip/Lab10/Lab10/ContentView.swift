//
//  ContentView.swift
//  Lab10
//
//  Created by user on 27/5/21.
//

import SwiftUI
import FirebaseFirestore
import FirebaseFirestoreSwift

struct Task : Codable, Identifiable{
    @DocumentID var id: String?
    let title:String
    let done:String
    let expiredDate:String
}

struct ContentView: View {
    
    @State private var title:String = ""
    @State private var done:String = ""
    @State private var expiredDate = Date()
    @State private var task:Task = Task(title: "無", done: "無", expiredDate: "無")
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .leading, vertical: .top)){
            Color.black.ignoresSafeArea()
            VStack{
                HStack{
                    Spacer()
                    Text("ToDo App")
                        .bold()
                        .font(.system(size: 32))
                        .foregroundColor(.white)
                    Spacer()
                }
                .padding(.bottom, 32)
                
                VStack(spacing:16){
                    HStack{
                        Spacer()
                        Text("輸入數據")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                        Spacer()
                    }
                    .padding(.bottom, 16)
                    
                    HStack{
                        Text("名稱：")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                        ZStack(alignment: .leading){
                            Text( title.isEmpty ? "請輸入名稱" : "")
                                .foregroundColor(.gray)
                            TextField("", text: $title)
                                .foregroundColor(.white)
                        }
                    }
                    HStack{
                        Text("是否完成：")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                        ZStack(alignment: .leading){
                            Text( done.isEmpty ? "請輸入“是”或“否”" : "")
                                .foregroundColor(.gray)
                            TextField("", text: $done)
                                .foregroundColor(.white)
                        }
                    }
                    HStack{
                        Text("到期時間：")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                        DatePicker("", selection: $expiredDate, in: ...Date())
                    }
                }
                .padding(.top, 16)
                .padding(.bottom, 16)
                
                
                Button("新增數據"){
                    let db = Firestore.firestore()
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "MMM dd,yyyy hh:mm a"
                    let task = Task(title: title, done: done, expiredDate: dateFormatter.string(from: expiredDate))
                    do{
                        try db.collection("Todo").document("Task").setData(from: task)
                    }
                    catch{
                        print(error)
                    }
                }
                .padding(.bottom, 16)
                
                Text("---------------------------------------------")
                    .foregroundColor(.white)
                    .frame(minWidth:0, maxWidth: .infinity)
                
                VStack(alignment: .leading, spacing:16){
                    HStack{
                        Spacer()
                        Text("目前數據")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                        Spacer()
                    }
                    .padding(.bottom, 16)
                    
                    HStack{
                        Text("名稱：")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                        Text(task.title)
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                    }
                    HStack{
                        Text("是否完成：")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                        Text(task.done)
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                    }
                    HStack{
                        Text("到期時間：")
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                        Text(task.expiredDate)
                            .font(.system(size: 20))
                            .foregroundColor(.white)
                    }
                }
                .padding(.top, 16)
                .padding(.bottom, 16)
                
                Button("讀取數據"){
                    let db = Firestore.firestore()
                    db.collection("Todo").document("Task").getDocument{
                        document, error in
                        guard let document = document,
                              document.exists,
                              let loadedTask = try? document.data(as: Task.self)
                        else{
                            return
                        }
                        task = loadedTask
                    }
                }
            }
            .padding(.leading, 16)
            .padding(.trailing, 16)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
